﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class CommandLine
{
    public static void Main()
    {

        Console.WriteLine(" SSSSS   TTTTTT");
        Console.WriteLine("S          TT");
        Console.WriteLine(" SSSS      TT");
        Console.WriteLine("     S     TT");
        Console.WriteLine("     S     TT");
        Console.WriteLine("SSSSS      TT");
    }
}